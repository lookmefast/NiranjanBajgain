import React from 'react'

const  Abouts= ()=> {
    return (
        <div>
            <h1 className = 'display-4'>About Bishworaj Poudel</h1>
            <p className="lead">
                Simple app that helps to manage the contact.
            </p>
            <p className="text-secondary">
                Version: 1.0.0
            </p>
        </div>
    )
}

export default Abouts;
